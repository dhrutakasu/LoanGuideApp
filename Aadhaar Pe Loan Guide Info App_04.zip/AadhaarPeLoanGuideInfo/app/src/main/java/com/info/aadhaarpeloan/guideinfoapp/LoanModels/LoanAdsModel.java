package com.info.aadhaarpeloan.guideinfoapp.LoanModels;


public class LoanAdsModel{

	private String bad;

	private String btype;

	private String fiad;

	private String login;

	private String startappid;

	private String siad;

	private String pkg;

	private String preload;

	private String iad;

	private String querkalink;

	private String nad;

	private String liad;

	private String oad2;

	private String oad;

	private String lnad;

	private String fnad;

	private String ownn;

	private String itype;

	private String appAdsButtonTextColor;

	private String ownblink;

	private String backads;

	private String ownb;

	private String lbad;

	private String ntype;

	private String fnbad;

	private String fbad;

	private String nad2;

	private String closeadopen;

	private String appAdsButtonColor;

	private String telegramlink;

	private String adscount;

	private String appPrivacyPolicyLink;

	private String ownnlink;

	public void setBad(String bad){
		this.bad = bad;
	}

	public String getBad(){
		return bad;
	}

	public void setBtype(String btype){
		this.btype = btype;
	}

	public String getBtype(){
		return btype;
	}

	public void setFiad(String fiad){
		this.fiad = fiad;
	}

	public String getFiad(){
		return fiad;
	}

	public void setLogin(String login){
		this.login = login;
	}

	public String getLogin(){
		return login;
	}

	public void setStartappid(String startappid){
		this.startappid = startappid;
	}

	public String getStartappid(){
		return startappid;
	}

	public void setSiad(String siad){
		this.siad = siad;
	}

	public String getSiad(){
		return siad;
	}

	public void setPkg(String pkg){
		this.pkg = pkg;
	}

	public String getPkg(){
		return pkg;
	}

	public void setPreload(String preload){
		this.preload = preload;
	}

	public String getPreload(){
		return preload;
	}

	public void setIad(String iad){
		this.iad = iad;
	}

	public String getIad(){
		return iad;
	}

	public void setQuerkalink(String querkalink){
		this.querkalink = querkalink;
	}

	public String getQuerkalink(){
		return querkalink;
	}

	public void setNad(String nad){
		this.nad = nad;
	}

	public String getNad(){
		return nad;
	}

	public void setLiad(String liad){
		this.liad = liad;
	}

	public String getLiad(){
		return liad;
	}

	public void setOad2(String oad2){
		this.oad2 = oad2;
	}

	public String getOad2(){
		return oad2;
	}

	public void setOad(String oad){
		this.oad = oad;
	}

	public String getOad(){
		return oad;
	}

	public void setLnad(String lnad){
		this.lnad = lnad;
	}

	public String getLnad(){
		return lnad;
	}

	public void setFnad(String fnad){
		this.fnad = fnad;
	}

	public String getFnad(){
		return fnad;
	}

	public void setOwnn(String ownn){
		this.ownn = ownn;
	}

	public String getOwnn(){
		return ownn;
	}

	public void setItype(String itype){
		this.itype = itype;
	}

	public String getItype(){
		return itype;
	}

	public void setAppAdsButtonTextColor(String appAdsButtonTextColor){
		this.appAdsButtonTextColor = appAdsButtonTextColor;
	}

	public String getAppAdsButtonTextColor(){
		return appAdsButtonTextColor;
	}

	public void setOwnblink(String ownblink){
		this.ownblink = ownblink;
	}

	public String getOwnblink(){
		return ownblink;
	}

	public void setBackads(String backads){
		this.backads = backads;
	}

	public String getBackads(){
		return backads;
	}

	public void setOwnb(String ownb){
		this.ownb = ownb;
	}

	public String getOwnb(){
		return ownb;
	}

	public void setLbad(String lbad){
		this.lbad = lbad;
	}

	public String getLbad(){
		return lbad;
	}

	public void setNtype(String ntype){
		this.ntype = ntype;
	}

	public String getNtype(){
		return ntype;
	}

	public void setFnbad(String fnbad){
		this.fnbad = fnbad;
	}

	public String getFnbad(){
		return fnbad;
	}

	public void setFbad(String fbad){
		this.fbad = fbad;
	}

	public String getFbad(){
		return fbad;
	}

	public void setNad2(String nad2){
		this.nad2 = nad2;
	}

	public String getNad2(){
		return nad2;
	}

	public void setCloseadopen(String closeadopen){
		this.closeadopen = closeadopen;
	}

	public String getCloseadopen(){
		return closeadopen;
	}

	public void setAppAdsButtonColor(String appAdsButtonColor){
		this.appAdsButtonColor = appAdsButtonColor;
	}

	public String getAppAdsButtonColor(){
		return appAdsButtonColor;
	}

	public void setTelegramlink(String telegramlink){
		this.telegramlink = telegramlink;
	}

	public String getTelegramlink(){
		return telegramlink;
	}

	public void setAdscount(String adscount){
		this.adscount = adscount;
	}

	public String getAdscount(){
		return adscount;
	}

	public void setAppPrivacyPolicyLink(String appPrivacyPolicyLink){
		this.appPrivacyPolicyLink = appPrivacyPolicyLink;
	}

	public String getAppPrivacyPolicyLink(){
		return appPrivacyPolicyLink;
	}

	public void setOwnnlink(String ownnlink){
		this.ownnlink = ownnlink;
	}

	public String getOwnnlink(){
		return ownnlink;
	}

	@Override
 	public String toString(){
		return 
			"LoanAdsModel{" + 
			"bad = '" + bad + '\'' + 
			",btype = '" + btype + '\'' + 
			",fiad = '" + fiad + '\'' + 
			",login = '" + login + '\'' + 
			",startappid = '" + startappid + '\'' + 
			",siad = '" + siad + '\'' + 
			",pkg = '" + pkg + '\'' + 
			",preload = '" + preload + '\'' + 
			",iad = '" + iad + '\'' + 
			",querkalink = '" + querkalink + '\'' + 
			",nad = '" + nad + '\'' + 
			",liad = '" + liad + '\'' + 
			",oad2 = '" + oad2 + '\'' + 
			",oad = '" + oad + '\'' + 
			",lnad = '" + lnad + '\'' + 
			",fnad = '" + fnad + '\'' + 
			",ownn = '" + ownn + '\'' + 
			",itype = '" + itype + '\'' + 
			",appAdsButtonTextColor = '" + appAdsButtonTextColor + '\'' + 
			",ownblink = '" + ownblink + '\'' + 
			",backads = '" + backads + '\'' + 
			",ownb = '" + ownb + '\'' + 
			",lbad = '" + lbad + '\'' + 
			",ntype = '" + ntype + '\'' + 
			",fnbad = '" + fnbad + '\'' + 
			",fbad = '" + fbad + '\'' + 
			",nad2 = '" + nad2 + '\'' + 
			",closeadopen = '" + closeadopen + '\'' + 
			",appAdsButtonColor = '" + appAdsButtonColor + '\'' + 
			",telegramlink = '" + telegramlink + '\'' + 
			",adscount = '" + adscount + '\'' + 
			",app_privacyPolicyLink = '" + appPrivacyPolicyLink + '\'' + 
			",ownnlink = '" + ownnlink + '\'' + 
			"}";
		}
}